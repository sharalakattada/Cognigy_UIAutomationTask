/// <reference types="Cypress" />

import progressbar from "../../PageObjects/ProgressBarPage";

describe('Progress_Bar', function () {

    it('Progress Bar Test01 ', function () {

        /*To visit the Progress Bar Element Page*/

        cy.visit("http://localhost:3000/progressbar")

        const ln=new progressbar();
        ln.clickStartButton();
        ln.verifyStopProgressBarRec();
          
    });
});