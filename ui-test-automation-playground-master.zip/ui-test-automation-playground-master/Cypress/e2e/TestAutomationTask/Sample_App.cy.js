/// <reference types="Cypress" />
import sampleApp from "../../PageObjects/SampleAppPage"

describe('Sample_App', function () {

    it('Sample App Test01 ', function () {

        /*To visit the Sample App Element Page*/

        cy.visit("http://localhost:3000/sampleapp")

         //Successful login verification
         cy.fixture('applicationTestData1').then((data)=>{

         const ln=new sampleApp();
         ln.setUserName(data.username)
         ln.setPassword(data.password)
         ln.clickSubmit();
         ln.verifyLoginStatus();
         })
         
         })
})