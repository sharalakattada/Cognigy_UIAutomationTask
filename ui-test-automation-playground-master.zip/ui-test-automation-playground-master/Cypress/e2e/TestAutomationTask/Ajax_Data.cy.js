/// <reference types="Cypress" />
import AjaxData from "../../PageObjects/AjaxDataPage";

describe('Ajax_Data', function () {

    it('Ajax Data Test01 ', function () {

        /*To visit the Ajax Data Element Page*/
        cy.visit("http://localhost:3000/ajax")

         //Click the button and wait for the data to appear on the label
         const ln=new AjaxData();
         ln.clickButtonTrigerringAjaxReq();
         ln.verifySuccessLabelText();
    })
})