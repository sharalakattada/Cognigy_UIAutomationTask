/// <reference types="Cypress" />
import textInputPage from "../../PageObjects/TextInputPage"

describe('Text_Input', function () {

    it('Text Input Test01 ', function () {

        /*To visit the Text Input Element Page*/

        cy.visit("http://localhost:3000/textinput")

          //Type and validate the Button Name
          cy.fixture('applicationTestData1').then((data)=>{
          const ln=new textInputPage();
          ln.setNewButtonName(data.buttonname)
          ln.clickButton();
          ln.verifyNewButtonName();
        })
          })
})