class AjaxData
{
clickAjaxReqButton="[id='ajaxButton']";
successLabelText="[class='bg-success']";


    clickButtonTrigerringAjaxReq(){
        cy.get(this.clickAjaxReqButton).click() 
    }

    verifySuccessLabelText(){
        cy.get(this.successLabelText, { timeout: 20000 }).should('be.visible').contains('Data loaded with AJAX get request');   
    }      

}

export default AjaxData