class textInputPage
{
    inputButtonName="[id='newButtonName']";
    clickBtn="[id='updatingButton']";
    newInputButtonName="[id='updatingButton']";

    setNewButtonName(buttonname){
        cy.get(this.inputButtonName).type(buttonname)
    }

    clickButton(){
        cy.get(this.clickBtn).click()
    }
    
      verifyNewButtonName(){
        cy.get(this.newInputButtonName).should('have.text',"Testing the Text Input Field")
     }       

}
export default textInputPage