class sampleApp
{
    userName="[name='UserName']";
    password="[name='Password']";
    loginButton="[id='login']";
    loginStatus="[id='loginstatus']";

    setUserName(username){
        cy.get(this.userName).focus().type(username).blur()
    }

    setPassword(password){
        cy.get(this.password).type(password)
    }

    clickSubmit(){
        cy.get(this.loginButton).click()
    }
    
    verifyLoginStatus(){
        cy.get('[id="loginstatus"]').should('be.visible').contains("Welcome, user name!")
       }        
         
}
export default sampleApp