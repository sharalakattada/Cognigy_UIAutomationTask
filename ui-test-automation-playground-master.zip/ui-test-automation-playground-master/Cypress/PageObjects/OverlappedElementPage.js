class overlappedElement
{
    overlappedElementInputField="[id='id']";

    inputOverlappedElementData(inputData){
        cy.get(this.overlappedElementInputField).scrollIntoView().should('be.visible').type(inputData)
    }
    
    verifyInputData(){
        cy.get(this.overlappedElementInputField).scrollIntoView().should('have.value',"hello")
    }
    
}
export default overlappedElement