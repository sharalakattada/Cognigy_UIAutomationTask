/// <reference types="Cypress" />

describe('Text_Input', function () {

    it('Text Input Test01 ', function () {

        /*To visit the Text Input Element Page*/

        cy.visit("http://localhost:3000/overlapped")

          //Type and validate the Button Name
        cy.get('[id="newButtonName"]').type(Application.sampletext)
        cy.get('[id="updatingButton"]').click()
        cy.get('[id="updatingButton"]').should('have.text',Application.sampletext)
    })
})