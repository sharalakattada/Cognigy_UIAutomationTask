/// <reference types="Cypress" />

describe('Ajax_Data', function () {

    it('Ajax Data Test01 ', function () {

        /*To visit the Ajax Data Element Page*/

        cy.visit("http://localhost:3000/overlapped")

         //Click the button and wait for the data to appear on the label
         cy.get('[id="ajaxButton"]').click()
         cy.get('[.user_email_ajax]', { timeout: 20000 }).should('be.visible').contains('Data loaded with AJAX get request');   
    })
})