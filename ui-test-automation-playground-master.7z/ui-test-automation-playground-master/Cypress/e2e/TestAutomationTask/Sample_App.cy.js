/// <reference types="Cypress" />

describe('Sample_App', function () {

    it('Sample App Test01 ', function () {

        /*To visit the Sample App Element Page*/

        cy.visit("http://localhost:3000/overlapped")

         //Successful login verification
         cy.get('[name="UserName"]').focus().type(Application.username).blur()
         cy.get('[name="Password"]').type(Application.password)
         cy.get('[id="login"]').click()
         cy.get('[id="loginstatus"]').should('be.visible').contains(Application.username) 
    })
})