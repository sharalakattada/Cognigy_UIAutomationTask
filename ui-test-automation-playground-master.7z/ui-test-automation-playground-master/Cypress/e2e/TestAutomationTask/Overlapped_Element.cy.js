/// <reference types="Cypress" />

describe('Overlapped_Element', function () {

    it('Overlapped Element Test01 ', function () {

        /*To visit the Overlapped Element Page*/

        cy.visit("http://localhost:3000/overlapped")

        //Scroll and enter the text in the name field
        cy.get('[id="id"]').scrollIntoView().should('be.visible').type("hello")
        cy.get('[id="id"]').scrollIntoView().should('have.value',"hello")
    })
})